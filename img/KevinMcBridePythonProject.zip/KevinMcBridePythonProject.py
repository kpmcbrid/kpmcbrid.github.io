#Name: Kevin McBride
#Project: Python Project
#Class: GIS III

import arcpy

#Workspace
Workspace =  arcpy.GetParameterAsText(0)
arcpy.env.workspace = Workspace 

#Variables
GDBfile = arcpy.GetParameterAsText(1)
Projection = arcpy.GetParameterAsText(2)
New_Projected = arcpy.GetParameterAsText(3)

#Geodatabase
arcpy.CreateFileGDB_management(Workspace, GDBfile)

#Projections

New_Projections = arcpy.ListFeatureClasses()
print New_Projections

for fc in New_Projections:
    output = fc.replace(".shp","_newfile.shp")
    arcpy.Project_management(fc, output, Projection)


#Clipping New Projections

for fc in New_Projections:
    OUTPUT= fc.replace (".shp","clip")
    arcpy.Clip_analysis (fc,New_Projected,Workspace+"/"+GDBfile+".gdb/"+OUTPUT,)
    
